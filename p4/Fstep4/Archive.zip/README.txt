A Pen created at CodePen.io. You can find this one at https://codepen.io/kensnyder/pen/lfGiI.

 This is just a copy of the work done by Jasny: http://jsfiddle.net/jasny/2vj0ec8c/